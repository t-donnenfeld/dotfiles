return {
  { "folke/lazy.nvim", lazy = false },
}
